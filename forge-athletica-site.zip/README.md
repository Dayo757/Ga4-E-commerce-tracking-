# GA4 E-commerce Tracking via GTM: Forge Athletica Demo Store

> A fictional gym-wear store built to practise and demonstrate GA4 e-commerce tracking implemented through Google Tag Manager and a custom dataLayer.

**Live demo:** [https://dayo757.github.io/ga4-ecommerce-tracking/](https://dayo757.github.io/Ga4-E-commerce-tracking-/)

## Goal
_One or two lines: what you set out to implement and why._

## Tracking plan

**Type** shows where each event comes from: **Recommended** = GA4's official event name, **Automatic** = collected by GA4 enhanced measurement with no code, **Custom** = my own name where GA4 has no standard event. Tick **Status** once the event is verified in GTM Preview *and* GA4 DebugView.

### Page data (pushed on every page, above GTM)

| Key | Example values | Used for |
|---|---|---|
| `page_type` | home, product, cart, checkout, purchase_confirmation, account, contact | GTM triggers, GA4 custom dimension |
| `site_environment` | test | Filtering out test traffic |
| `login_status` | logged_in, logged_out | GA4 custom dimension |
| `user_id` | FA-U-3f9a1c2e (random, never PII) | GA4 cross-device user ID |

### E-commerce

| Event | Type | Page / trigger | Key parameters | Status |
|---|---|---|---|---|
| view_item_list | Recommended | Home page load | item_list_id, item_list_name, items (with index) | ☐ |
| select_item | Recommended | Product card click | item_list_id, items (with index) | ☐ |
| view_item | Recommended | Product page load | currency, value, items | ☐ |
| add_to_cart | Recommended | "Add to basket" click | currency, value (price × qty), items | ☐ |
| remove_from_cart | Recommended | "Remove" click in basket | currency, value, items | ☐ |
| view_cart | Recommended | Basket page load (once, not on re-render) | currency, value, items | ☐ |
| begin_checkout | Recommended | Checkout page load | currency, value, items | ☐ |
| add_shipping_info | Recommended | "Continue to payment" | currency, value, shipping_tier, items | ☐ |
| add_payment_info | Recommended | "Place order" | currency, value, payment_type, items | ☐ |
| purchase | Recommended | Thank-you page load (once, refresh-safe) | transaction_id, currency, value (subtotal), shipping, coupon, items | ☐ |

### Accounts and leads

| Event | Type | Page / trigger | Key parameters | Status |
|---|---|---|---|---|
| sign_up | Recommended | Account page: "Create account" | method | ☐ |
| login | Recommended | Account page: "Log in" | method | ☐ |
| logout | Custom | Account page: "Log out" | (none) | ☐ |
| generate_lead | Recommended | Home newsletter form | lead_source: home_form, form_name: newsletter | ☐ |
| generate_lead | Recommended | Product page pop-up | lead_source: popup, form_name: newsletter | ☐ |
| generate_lead | Recommended | Contact form | lead_source: contact_form, form_name: contact, contact_topic | ☐ |
| popup_view | Custom | Pop-up appears (product pages, once per session) | popup_name | ☐ |
| popup_close | Custom | Pop-up "×" click | popup_name | ☐ |
| contact_click | Custom | Phone / email link on contact page | contact_method, link_url | ☐ |

### Content (GA4 enhanced measurement, no code)

| Event | Type | Page / trigger | Key parameters | Status |
|---|---|---|---|---|
| page_view | Automatic | Every page load | page_location, page_title | ☐ |
| scroll | Automatic | 90% page depth | percent_scrolled | ☐ |
| file_download | Automatic | Size guide PDF link (product pages) | file_name, file_extension, link_url | ☐ |
| click (outbound) | Automatic | Instagram / Stockists footer links | link_url, link_domain, outbound | ☐ |
| video_start / video_progress / video_complete | Automatic | YouTube video on home page | video_title, video_percent | ☐ |

### Shared on every dataLayer event

- `event_id`: unique per event, used by Meta to deduplicate browser Pixel + server CAPI.
- `user_data.sha256_email_address`: hashed email (SHA-256, trimmed and lowercased), once the visitor has entered an email this session, and only with Marketing consent when `REQUIRE_CONSENT` is on.

## dataLayer specification
_Paste the push for each event and explain the structure (items array, currency, value)._

## GTM configuration
_Screenshots of tags, triggers and variables. Link to the exported container: `gtm/container.json`._

## QA & validation
_GTM Preview and GA4 DebugView screenshots showing each event and its parameters._

## Issues & fixes
_What broke, how you found it, how you fixed it. Example: duplicate purchase events on refresh._

## What I'd do next
_e.g. server-side GTM, Meta Conversions API with deduplication, Consent Mode v2._

---

### Project structure
```
index.html          product listing, video, newsletter form
product.html        product detail (?id=FA-001), size guide link, newsletter pop-up (?popup=off to disable)
cart.html           basket
checkout.html       delivery + payment steps
thank-you.html      order confirmation
account.html        demo sign-up / log-in / log-out (no passwords stored)
contact.html        contact form, phone and email links
size-guide.pdf      file for download tracking
shop.js             store logic + dataLayer. Settings (REQUIRE_CONSENT, POPUP_DELAY_MS) at the top
style.css           styling
```
